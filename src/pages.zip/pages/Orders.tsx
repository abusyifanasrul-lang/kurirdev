import { useState, useMemo, useEffect } from 'react';
import { Plus, Download, Search, ArrowUpDown, ChevronUp, ChevronDown, Printer, Pencil, Trash2, Check, XCircle } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { sendPushNotification } from '@/services/notificationService';
import {
  getCachedOrdersByRange,
  cacheOrdersByDate,
  getOrdersForWeek,
  getUnpaidOrdersByCourier,
  markAsPaidInLocalDB,
  getOrdersByDateRange
} from '@/lib/orderCache';
import { Header } from '@/components/layout/Header';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Modal } from '@/components/ui/Modal';
import { Textarea } from '@/components/ui/Textarea';
import { Badge, getStatusBadgeVariant, getStatusLabel } from '@/components/ui/Badge';
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableHeader,
  TableCell,
  TableEmpty,
} from '@/components/ui/Table';

// Stores & Types
import { useOrderStore } from '@/stores/useOrderStore';
import { useCourierStore } from '@/stores/useCourierStore';
import { useUserStore } from '@/stores/useUserStore';
import { useNotificationStore } from '@/stores/useNotificationStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useCustomerStore } from '@/stores/useCustomerStore';
import { useAuth } from '@/context/AuthContext';
import type { Order, CreateOrderPayload, PaymentStatus, Customer } from '@/types';

const statusOptions = [
  { value: '', label: 'Semua Status' },
  { value: 'pending', label: '⏳ Menunggu Kurir' },
  { value: 'assigned', label: '📲 Kurir Ditugaskan' },
  { value: 'picked_up', label: '🛵 GAS — Menuju Penjual' },
  { value: 'in_transit', label: '🛵 GAS — Menuju Customer' },
  { value: 'delivered', label: '✅ CEKLIS — Terkirim' },
  { value: 'cancelled', label: '❌ CANCEL — Dibatalkan' },
];

const searchCategories = [
  { value: 'all', label: 'All Fields' },
  { value: 'order_number', label: 'Order ID' },
  { value: 'customer_name', label: 'Customer' },
  { value: 'customer_phone', label: 'Phone' },
  { value: 'courier_name', label: 'Courier' },
  { value: 'customer_address', label: 'Address' },
];

type SortField = 'order_number' | 'customer_name' | 'status' | 'courier_id' | 'payment_status' | 'total_fee' | 'created_at';
type SortOrder = 'asc' | 'desc';

export function Orders() {
  const { orders, fetchOrdersByDateRange, addOrder, assignCourier, cancelOrder, generateOrderId, updateOrder } = useOrderStore();
  const { rotateQueue } = useCourierStore();
  const { users } = useUserStore();
  const { addNotification } = useNotificationStore();
  const { user } = useAuth(); // Current admin user
  const { commission_rate, commission_threshold, courier_instructions } = useSettingsStore();

  const isOpsAdmin = user?.role === 'admin_kurir' || user?.role === 'admin';
  const isFinance = user?.role === 'finance' || user?.role === 'admin' || user?.role === 'owner';

  // Cache State
  const [cacheStatus, setCacheStatus] = useState<'idle' | 'checking' | 'missing' | 'loading' | 'loaded'>('idle')
  const [missingDates, setMissingDates] = useState<string[]>([])
  const [cachedOrders, setCachedOrders] = useState<Order[]>([])

  // Bulk Settlement State
  const [showBulkSettle, setShowBulkSettle] = useState(false)
  const [bulkSettleCourierName, setBulkSettleCourierName] = useState<string>('')
  const [bulkUnpaidOrders, setBulkUnpaidOrders] = useState<Order[]>([])

  // Local DB State for weekly orders
  const [localDBOrders, setLocalDBOrders] = useState<Order[]>([])

  const getCourierName = (courierId?: string) => {
    if (!courierId) return null;
    const courier = users.find(u => u.id === courierId);
    return courier?.name || null;
  };


  const allOrders = useMemo(() => {
    // Gabungkan: IndexedDB (pekan ini) +
    // Zustand (aktif)
    const map = new Map<string, Order>()

    // IndexedDB data (pekan ini, final)
    localDBOrders.forEach(o =>
      map.set(o.id, o)
    )

    // Zustand data (aktif, realtime)
    // Override IndexedDB jika ada update
    orders.forEach(o => map.set(o.id, o))

    // Cache data (dari filter tanggal manual)
    if (cacheStatus === 'loaded' &&
        cachedOrders.length > 0) {
      cachedOrders.forEach(o =>
        map.set(o.id, o)
      )
    }

    return Array.from(map.values())
  }, [orders, localDBOrders,
      cachedOrders, cacheStatus])

  const calcPlatformFee = (order: Order) => {
    const rate = order.applied_commission_rate ?? commission_rate
    const threshold = order.applied_commission_threshold ?? commission_threshold
    if (order.total_fee <= threshold) return 0
    return order.total_fee * (1 - rate / 100)
  }

  const [searchQuery, setSearchQuery] = useState('');
  const [searchCategory, setSearchCategory] = useState('all');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [dateFilter, setDateFilter] = useState({ start: '', end: '' });
  const [sortConfig, setSortConfig] = useState<{ field: SortField; order: SortOrder }>({
    field: 'created_at',
    order: 'desc',
  });

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [assignCourierId, setAssignCourierId] = useState<string>('');
  const [formError, setFormError] = useState('');
  const [editItems, setEditItems] = useState<{ nama: string; harga: number }[]>([]);
  const [editItemNama, setEditItemNama] = useState('');
  const [editItemHarga, setEditItemHarga] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // Form State
  const [newOrder, setNewOrder] = useState<CreateOrderPayload>({
    customer_name: '',
    customer_phone: '',
    customer_address: '',
    total_fee: 0,
    payment_status: 'unpaid',
    estimated_delivery_time: '',
    items: [] as { nama: string; harga: number }[],
    notes: '',
  });

  // Edit Form State
  const [editForm, setEditForm] = useState<{
    customer_name: string;
    customer_phone: string;
    customer_address: string;
    total_fee: number;
    payment_status: PaymentStatus;
  }>({
    customer_name: '',
    customer_phone: '',
    customer_address: '',
    total_fee: 0,
    payment_status: 'unpaid',
  });

  const [cancelReason, setCancelReason] = useState('');

  const { search: searchCustomers, upsertCustomer, addAddress, updateAddress, deleteAddress, findByPhone } = useCustomerStore()
  const [customerSuggestions, setCustomerSuggestions] = useState<Customer[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  // showNewAddressInput reserved - unused after inline-edit refactor
  const [inlineEditAddrId, setInlineEditAddrId] = useState<string | null>(null)
  const [inlineEditValue, setInlineEditValue] = useState('')
  const [inlineNewAddr, setInlineNewAddr] = useState('')
  const [inlineAddingNew, setInlineAddingNew] = useState(false)

  // Edit modal inline address state (for Order Details edit)
  const [editSelectedCustomer, setEditSelectedCustomer] = useState<Customer | null>(null)
  const [editInlineAddrId, setEditInlineAddrId] = useState<string | null>(null)
  const [editInlineAddrValue, setEditInlineAddrValue] = useState('')
  const [editInlineAddingNew, setEditInlineAddingNew] = useState(false)

  const handleCustomerNameChange = (value: string) => {
    setNewOrder({ ...newOrder, customer_name: value })
    setSelectedCustomer(null)
    setInlineEditAddrId(null)
    setInlineAddingNew(false)
    if (value.length >= 2) {
      setCustomerSuggestions(searchCustomers(value).slice(0, 5))
      setShowSuggestions(true)
    } else {
      setShowSuggestions(false)
    }
  }

  const handleSelectCustomer = (customer: Customer) => {
    const defaultAddress = customer.addresses.find(a => a.is_default) || customer.addresses[0]
    setNewOrder({ 
      ...newOrder, 
      customer_name: customer.name, 
      customer_phone: customer.phone, 
      customer_address: defaultAddress ? defaultAddress.address : '' 
    })
    setSelectedCustomer(customer)
    setInlineEditAddrId(null)
    setInlineAddingNew(false)
    setShowSuggestions(false)
  }

  // Derived State
  const filteredOrders = useMemo(() => {
    return allOrders
      .filter((order) => {
        const matchesStatus = !statusFilter || order.status === statusFilter;

        // Gunakan _date local untuk perbandingan
        // bukan created_at UTC
        const orderLocalDate = (order as any)._date ||
          (() => {
            const d = new Date(order.created_at)
            const y = d.getFullYear()
            const m = String(d.getMonth() + 1)
              .padStart(2, '0')
            const day = String(d.getDate())
              .padStart(2, '0')
            return `${y}-${m}-${day}` 
          })()

        const matchesDateStart = !dateFilter.start ||
          orderLocalDate >= dateFilter.start
        const matchesDateEnd = !dateFilter.end ||
          orderLocalDate <= dateFilter.end

        // Advanced Search Logic
        const q = searchQuery.toLowerCase();
        let matchesSearch = !searchQuery;

        if (searchQuery) {
          if (searchCategory === 'all') {
            matchesSearch =
              order.order_number.toLowerCase().includes(q) ||
              order.customer_name.toLowerCase().includes(q) ||
              order.customer_phone.includes(searchQuery) ||
              (getCourierName(order.courier_id)?.toLowerCase().includes(q) || false) ||
              order.customer_address.toLowerCase().includes(q);
          } else if (searchCategory === 'order_number') {
            matchesSearch = order.order_number.toLowerCase().includes(q);
          } else if (searchCategory === 'customer_name') {
            matchesSearch = order.customer_name.toLowerCase().includes(q);
          } else if (searchCategory === 'customer_phone') {
            matchesSearch = order.customer_phone.includes(searchQuery);
          } else if (searchCategory === 'courier_name') {
            matchesSearch = getCourierName(order.courier_id)?.toLowerCase().includes(q) || false;
          } else if (searchCategory === 'customer_address') {
            matchesSearch = order.customer_address.toLowerCase().includes(q);
          }
        }

        return matchesStatus && matchesDateStart && matchesDateEnd && matchesSearch;
      })
      .sort((a, b) => {
        const field = sortConfig.field;
        const order = sortConfig.order;

        let aValue: any = field === 'courier_id' ? getCourierName(a[field]) || '' : a[field] || '';
        let bValue: any = field === 'courier_id' ? getCourierName(b[field]) || '' : b[field] || '';

        if (typeof aValue === 'string') aValue = aValue.toLowerCase();
        if (typeof bValue === 'string') bValue = bValue.toLowerCase();

        if (aValue < bValue) return order === 'asc' ? -1 : 1;
        if (aValue > bValue) return order === 'asc' ? 1 : -1;
        return 0;
      });
  }, [allOrders, searchQuery, searchCategory, statusFilter, dateFilter, sortConfig]);

  const handleSort = (field: SortField) => {
    setSortConfig(prev => ({
      field,
      order: prev.field === field && prev.order === 'asc' ? 'desc' : 'asc',
    }));
  };

  const getSortIcon = (field: SortField) => {
    if (sortConfig.field !== field) return <ArrowUpDown className="h-3 w-3 ml-1 text-gray-400" />;
    return sortConfig.order === 'asc' ?
      <ChevronUp className="h-3 w-3 ml-1 text-indigo-600" /> :
      <ChevronDown className="h-3 w-3 ml-1 text-indigo-600" />;
  };

  const availableCouriers = users
    .filter(u => u.role === 'courier' && u.is_active === true && u.is_online === true)
    .sort((a, b) => ((a as any).queue_position ?? 999) - ((b as any).queue_position ?? 999));

  const courierWaitingOrder = (courierId: string) =>
    allOrders.find(o => o.courier_id === courierId && o.is_waiting === true);

  useEffect(() => {
    const loadWeekOrders = async () => {
      const weekOrders = await getOrdersForWeek()
      setLocalDBOrders(weekOrders)
    }

    // Load pertama kali
    loadWeekOrders()

    // Listen jika IndexedDB baru diisi
    // oleh initial/delta sync
    window.addEventListener(
      'indexeddb-synced', loadWeekOrders
    )

    // Refresh setiap 30 detik untuk
    // menangkap perubahan dari mirror write
    const interval = setInterval(
      loadWeekOrders, 30000
    )

    return () => {
      window.removeEventListener(
        'indexeddb-synced', loadWeekOrders
      )
      clearInterval(interval)
    }
  }, [])

  // Sync edit form when order selected
  useEffect(() => {
    if (selectedOrder) {
      setEditForm({
        customer_name: selectedOrder.customer_name,
        customer_phone: selectedOrder.customer_phone,
        customer_address: selectedOrder.customer_address,
        total_fee: selectedOrder.total_fee,
        payment_status: selectedOrder.payment_status,
      });
      // Seed inline customer for address picker
      const cust = findByPhone(selectedOrder.customer_phone)
      setEditSelectedCustomer(cust || null)
      setEditInlineAddrId(null)
      setEditInlineAddingNew(false)
    }
  }, [selectedOrder?.id]);

  useEffect(() => {
    if (selectedOrder) {
      setEditItems(selectedOrder.items || []);
    }
  }, [selectedOrder?.id]);

  // Handlers
  const handleCreateOrder = async () => {
    const missing = [];
    if (!newOrder.customer_name?.trim())
      missing.push('Nama customer');
    if (!newOrder.customer_phone?.trim())
      missing.push('Nomor telepon');
    if (!newOrder.customer_address?.trim())
      missing.push('Alamat');
    if (missing.length > 0) {
      setFormError(`Wajib diisi: ${missing.join(', ')}`);
      return;
    }
    setFormError('');
    if (isCreating) return;
    setIsCreating(true);
    try {
      // Upsert Customer logic local state & firebase
      let customerId = selectedCustomer?.id;
      const existingCustomer = findByPhone(newOrder.customer_phone);

      if (existingCustomer) {
        customerId = existingCustomer.id;
        const existingAddress = existingCustomer.addresses.find(a => a.address === newOrder.customer_address);
        if (!existingAddress) {
          await addAddress(customerId, {
            label: `Alamat ${existingCustomer.addresses.length + 1}`,
            address: newOrder.customer_address,
            is_default: existingCustomer.addresses.length === 0,
            notes: ''
          });
        }
      } else {
        const newCustomer = await upsertCustomer({
          name: newOrder.customer_name,
          phone: newOrder.customer_phone,
          addresses: [{
            id: crypto.randomUUID(),
            label: 'Alamat Utama',
            address: newOrder.customer_address,
            is_default: true,
            notes: ''
          }]
        });
        customerId = newCustomer.id;
      }

      // Re-fetch customer to get exact address ID if newly added
      let activeAddressId = '';
      const latestCustomer = useCustomerStore.getState().findByPhone(newOrder.customer_phone);
      if (latestCustomer) {
        const matchingAddr = latestCustomer.addresses.find(a => a.address === newOrder.customer_address);
        if (matchingAddr) {
          activeAddressId = matchingAddr.id;
        }
      }

      const orderData: Order = {
        id: crypto.randomUUID(),
        order_number: generateOrderId(),
        ...newOrder,
        customer_id: customerId,
        customer_address_id: activeAddressId,
        total_fee: newOrder.total_fee || 0,
        status: 'pending',
        payment_status: newOrder.payment_status || 'unpaid',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        created_by: user?.id || "1",
      };

      await addOrder(orderData);
      setIsCreateModalOpen(false);
      setFormError('');
      setNewOrder({
        customer_name: '',
        customer_phone: '',
        customer_address: '',
        total_fee: 0,
        estimated_delivery_time: '',
        items: [],
        notes: '',
      });
    } catch (error) {
      setFormError('Gagal membuat order. Cek koneksi internet.');
    } finally {
      setIsCreating(false);
    }
  };

  const handleAssign = async () => {
    if (!selectedOrder || !assignCourierId) return;

    const courier = availableCouriers.find(c => c.id === assignCourierId);
    if (courier) {
      // Simpan instruksi (notes) ke order jika ada perubahan
      if (selectedOrder.notes !== undefined) {
        updateOrder(selectedOrder.id, { notes: selectedOrder.notes });
      }

      await assignCourier(selectedOrder.id, courier.id, courier.name, user?.id || "1", user?.name || 'Admin');
      await rotateQueue(courier.id);

      // Buat teks instruksi (dinamis dari settings)
      const notes = (selectedOrder.notes || '').toLowerCase().trim();
      const selectedInstruction = courier_instructions.find(
        instruction => instruction.label.toLowerCase() === notes
      );
      const emoji = selectedInstruction
        ? (selectedInstruction.icon || '📋')
        : '';
      const instruksi = selectedInstruction
        ? `${emoji} ${selectedInstruction.instruction}`
        : notes
        ? `📋 ${selectedOrder.notes}`
        : 'Segera proses!';

      const customerName = selectedOrder.customer_name || 'Customer';
      const notifTitle = `🛵 Order Baru — ${selectedOrder.order_number}`;
      const notifBody = `${customerName} • ${instruksi}`;

      // Simpan ke Firestore agar muncul di halaman notifikasi
      await addNotification({
        user_id: courier.id,
        user_name: courier.name,
        title: notifTitle,
        body: notifBody,
        data: { orderId: selectedOrder.id, type: 'order_assigned' },
      });

      // Kirim push notification ke HP kurir
      const courierData = users.find(u => u.id === courier.id);
      if (courierData?.fcm_token) {
        sendPushNotification({
          token: courierData.fcm_token,
          title: notifTitle,
          body: notifBody,
          data: { orderId: selectedOrder.id, type: 'order_assigned' }
        }).catch(console.error);
      }

      setIsDetailModalOpen(false);
      setAssignCourierId('');
    }
  };

  const handleCancel = async () => {
    if (!selectedOrder) return;
    await cancelOrder(selectedOrder.id, cancelReason, user?.id || '', user?.name || 'Admin', 'admin');
    setIsCancelModalOpen(false);
    setIsDetailModalOpen(false);
    setCancelReason('');
  };

  const handleSaveChanges = async () => {
    if (!selectedOrder) return;
    updateOrder(selectedOrder.id, {
      ...editForm,
      items: editItems
    });
    setSelectedOrder({
      ...selectedOrder,
      ...editForm,
      items: editItems
    });
  };

  const handleExportCSV = () => {
    const DELIM = ';';
    const q = (val: any) => `"${String(val ?? '').replace(/"/g, '""')}"`;

    const headers = [
      'Order ID', 'Tanggal', 'Customer', 'Telepon', 'Alamat',
      'Status', 'Kurir', 'Ongkir',
      'Titik', 'Total Biaya Beban', 'Total Ongkir',
      'Nama Barang', 'Total Belanja', 'Total Dibayar Customer',
      'Status Bayar', 'Instruksi Admin',
      'Jenis Cancel', 'Alasan Cancel',
      'Waktu Selesai', 'Waktu Cancel'
    ];

    const rows = filteredOrders.map(o => {
      const totalBiayaTitik = o.total_biaya_titik ?? 0;
      const totalBiayaBeban = o.total_biaya_beban ?? 0;
      const totalOngkir = (o.total_fee || 0) + totalBiayaTitik + totalBiayaBeban;

      const namaBarang = o.items && o.items.length > 0
        ? o.items.map(i => `${i.nama} (Rp ${i.harga.toLocaleString('id-ID')})`).join(' | ')
        : o.item_name || '';
      const totalBelanja = o.items && o.items.length > 0
        ? o.items.reduce((s, i) => s + i.harga, 0)
        : (o.item_price ?? 0);
      const totalDibayar = totalOngkir + totalBelanja;

      const cancelTypeLabel =
        o.cancel_reason_type === 'customer' ? 'Dibatalkan customer' :
        o.cancel_reason_type === 'item_unavailable' ? 'Barang tidak tersedia' :
        o.cancel_reason_type === 'other' ? 'Lainnya' : '';

      return [
        q(o.order_number),
        q(format(new Date(o.created_at), 'dd/MM/yyyy HH:mm')),
        q(o.customer_name),
        q(o.customer_phone),
        q(o.customer_address),
        q(getStatusLabel(o.status)),
        q(getCourierName(o.courier_id) || 'Belum Assign'),
        o.total_fee || 0,
        o.titik ?? 0,
        totalBiayaBeban,
        totalOngkir,
        q(namaBarang),
        totalBelanja > 0 ? totalBelanja : '',
        totalBelanja > 0 ? totalDibayar : totalOngkir,
        q(o.payment_status === 'paid' ? 'Sudah Setor' : 'Belum Setor'),
        q(o.notes || ''),
        q(cancelTypeLabel),
        q(o.cancellation_reason || ''),
        q(o.actual_delivery_time ? format(new Date(o.actual_delivery_time), 'dd/MM/yyyy HH:mm') : ''),
        q(o.cancelled_at ? format(new Date(o.cancelled_at), 'dd/MM/yyyy HH:mm') : ''),
      ];
    });

    const BOM = '\uFEFF';
    const csvContent = BOM + [headers.join(DELIM), ...rows.map(r => r.join(DELIM))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `orders_export_${format(new Date(), 'yyyyMMdd_HHmm')}.csv`;
    link.click();
  };

  const handlePrintInvoice = (order: Order) => {
    const titik = order.titik ?? 0;
    const beban = order.beban ?? [];
    const totalBiayaTitik = order.total_biaya_titik ?? 0;
    const totalBiayaBeban = order.total_biaya_beban ?? 0;
    const totalOngkir = (order.total_fee || 0) + totalBiayaTitik + totalBiayaBeban;
        const courierName = getCourierName(order.courier_id) || '-';

    const totalBelanja = (order.items && order.items.length > 0)
    ? order.items.reduce((s, i) => s + i.harga, 0)
    : (order.item_price ?? 0);

  const keteranganSection = (order.items && order.items.length > 0)
    ? `<div class="section">
        <div class="section-label">Daftar Belanja</div>
        ${order.items.map(item => `
          <div class="row">
            <span>${item.nama}</span>
            <span style="font-weight:600;">Rp ${item.harga.toLocaleString('id-ID')}</span>
          </div>
        `).join('')}
        <div class="row bold">
          <span>Total Belanja</span>
          <span>Rp ${totalBelanja.toLocaleString('id-ID')}</span>
        </div>
      </div>`
    : order.item_name
    ? `<div class="section">
        <div class="section-label">Barang</div>
        <div class="row">
          <span>${order.item_name}</span>
          ${order.item_price ? `<span style="font-weight:600;">Rp ${order.item_price.toLocaleString('id-ID')}</span>` : ''}
        </div>
      </div>`
    : '';

    const titikRows = titik > 0
      ? `<div style="padding:2px 0 2px 12px;color:#6b7280;font-size:12px;display:flex;justify-content:space-between;">
          <span>Titik Tambahan (${titik}x)</span><span>Rp ${totalBiayaTitik.toLocaleString('id-ID')}</span>
         </div>`
      : '';

    const bebanRows = beban.map(b =>
      `<div style="padding:2px 0 2px 12px;color:#6b7280;font-size:12px;display:flex;justify-content:space-between;">
        <span>• ${b.nama}</span><span>Rp ${b.biaya.toLocaleString('id-ID')}</span>
       </div>`
    ).join('');

    const printWindow = window.open('', '_blank', 'width=420,height=700');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8" />
        <title>Invoice ${order.order_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; background: #fff; color: #111; }
          .invoice { width: 360px; margin: 0 auto; padding: 24px; }
          .header { text-align: center; padding-bottom: 12px; border-bottom: 2px solid #111; margin-bottom: 14px; }
          .brand { font-size: 22px; font-weight: 800; color: #4338ca; }
          .brand-sub { font-size: 10px; color: #6b7280; letter-spacing: 0.1em; text-transform: uppercase; margin-top: 2px; }
          .order-number { font-size: 15px; font-weight: 700; margin-top: 10px; }
          .order-meta { font-size: 11px; color: #6b7280; margin-top: 2px; }
          .section { margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px dashed #d1d5db; }
          .section-label { font-size: 9px; font-weight: 700; letter-spacing: 0.1em; color: #6b7280; text-transform: uppercase; margin-bottom: 8px; }
          .row { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px; color: #374151; }
          .row.sub { padding-left: 10px; color: #9ca3af; }
          .row.bold { font-weight: 700; font-size: 13px; color: #111; padding-top: 6px; margin-top: 4px; border-top: 1px solid #e5e7eb; margin-bottom: 0; }
          .total-box { background: #fef3c7; border-radius: 8px; padding: 10px 12px; margin-bottom: 16px; }
          .total-box .total-row { display: flex; justify-content: space-between; font-size: 15px; font-weight: 800; color: #92400e; }
          .total-box .total-sub { font-size: 9px; color: #b45309; margin-top: 3px; }
          .footer { text-align: center; font-size: 11px; color: #9ca3af; padding-top: 12px; border-top: 1px dashed #e5e7eb; }
          @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
        </style>
      </head>
      <body>
        <div class="invoice">

          <div class="header">
            <div class="brand">🛵 KurirDev</div>
            <div class="brand-sub">Invoice Pengiriman</div>
            <div class="order-number">${order.order_number}</div>
            <div class="order-meta">${format(parseISO(order.created_at), 'dd MMM yyyy, HH:mm')}</div>
            <div class="order-meta">Kurir: ${courierName}</div>
          </div>

          <div class="section">
            <div class="section-label">Kepada</div>
            <div style="font-weight:700;font-size:13px;margin-bottom:4px;">${order.customer_name}</div>
            <div style="color:#4b5563;font-size:12px;margin-bottom:2px;">${order.customer_address}</div>
            <div style="color:#4b5563;font-size:12px;">${order.customer_phone}</div>
          </div>

          ${keteranganSection}

          <div class="section">
            <div class="section-label">Biaya Pengiriman</div>
            <div class="row"><span>Ongkir</span><span>Rp ${(order.total_fee || 0).toLocaleString('id-ID')}</span></div>
            ${titikRows}
            ${bebanRows}
            <div class="row bold"><span>Total Ongkir</span><span>Rp ${totalOngkir.toLocaleString('id-ID')}</span></div>
          </div>

          ${totalBelanja > 0
            ? `<div class="total-box">
                <div class="total-row">
                  <span>TOTAL DIBAYAR</span>
                  <span>Rp ${(totalOngkir + totalBelanja).toLocaleString('id-ID')}</span>
                </div>
                <div class="total-sub">Ongkir + ${order.items && order.items.length > 0 ? 'Total Belanja' : 'Harga Barang'}</div>
              </div>`
            : ''
          }

          <div class="footer">Terima kasih telah menggunakan layanan KurirDev 🙏</div>

        </div>
        <script>window.onload = () => { window.print(); window.onafterprint = () => window.close(); }<\/script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  const formatCurrency = (val: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(val);

  const handleDateFilterChange = async (
    start: string, end: string
  ) => {
    setDateFilter({ start, end })

    if (!start && !end) {
      setCacheStatus('idle')
      setCachedOrders([])
      return
    }

    const today = format(
      new Date(), 'yyyy-MM-dd'
    )
    if (start === today || !start) {
      setCacheStatus('idle')
      setCachedOrders([])
      return
    }

    setCacheStatus('checking')
    try {
      const results = await getOrdersByDateRange(
        start, end || start
      )

      if (results.length > 0) {
        setCachedOrders(results as Order[])
        setCacheStatus('loaded')
      } else {
        setMissingDates([start])
        setCacheStatus('missing')
      }
    } catch (error) {
      console.error('Filter error:', error)
      setCacheStatus('missing')
    }
  }

  const handleFetchAndCache = async () => {
    setCacheStatus('loading')
    try {
      const start = new Date(dateFilter.start)
      const end = new Date(dateFilter.end)

      // Fetch dari Firestore
      await fetchOrdersByDateRange(start, end)

      // Ambil data terbaru langsung dari store
      // (bukan dari historicalOrders state
      // yang belum re-render)
      const freshOrders = useOrderStore
        .getState().historicalOrders

      // Simpan ke cache per tanggal
      for (const date of missingDates) {
        const dayOrders = freshOrders
          .filter(o =>
            o.created_at.startsWith(date)
          )
        await cacheOrdersByDate(date, dayOrders)
      }

      // Baca dari cache untuk konfirmasi
      const { orders: cached } =
        await getCachedOrdersByRange(
          dateFilter.start,
          dateFilter.end
        )
      setCachedOrders(cached)
      setCacheStatus('loaded')

    } catch (error) {
      console.error('Cache error:', error)
      setCacheStatus('missing')
    }
  }

  return (
    <div className="min-h-screen">
      <Header
        title="Orders"
        subtitle="Kelola semua pesanan"
        actions={
          <div className="flex gap-2">
            {isFinance && (
              <Button variant="outline" leftIcon={<Download className="h-4 w-4" />} onClick={handleExportCSV}>
                Export CSV
              </Button>
            )}
            {isOpsAdmin && (
              <Button leftIcon={<Plus className="h-4 w-4" />} onClick={() => setIsCreateModalOpen(true)}>
                New Order
              </Button>
            )}
          </div>
        }
      />

      <div className="p-4 lg:p-8">
        {/* Records Count */}
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-gray-500">
            Menampilkan{' '}
            <span className="font-semibold text-gray-900">
              {filteredOrders.length}
            </span>
            {' '}order
            {filteredOrders.length !== allOrders.length && (
              <span className="text-gray-400">
                {' '}dari {allOrders.length} total
              </span>
            )}
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <div className="flex flex-col lg:flex-row flex-wrap gap-4">
            <div className="flex-1 min-w-[300px] flex gap-2">
              <div className="w-40">
                <Select
                  options={searchCategories}
                  value={searchCategory}
                  onChange={(e) => setSearchCategory(e.target.value)}
                />
              </div>
              <div className="flex-1">
                <Input
                  placeholder="Search orders..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  leftIcon={<Search className="h-4 w-4" />}
                />
              </div>
            </div>
            <div className="w-full lg:w-48">
              <Select
                options={statusOptions}
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                placeholder="All Status"
              />
            </div>
            <div className="flex gap-2 w-full lg:w-auto">
              <Input type="date" value={dateFilter.start} onChange={(e) => handleDateFilterChange(e.target.value, dateFilter.end)} />
              <Input type="date" value={dateFilter.end} onChange={(e) => handleDateFilterChange(dateFilter.start, e.target.value)} />
            </div>
          </div>
        </Card>

        {/* Cache Status UI */}
        {cacheStatus === 'missing' && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl">📦</span>
              <div className="flex-1">
                <p className="font-medium text-amber-800 text-sm">
                  Data belum tersimpan lokal
                </p>
                <p className="text-amber-700 text-xs mt-1">
                  {missingDates.length} hari belum di-cache
                </p>
                <p className="text-amber-600 text-xs mt-1">
                  Setelah diambil, data tersimpan permanen di perangkat ini.
                </p>
              </div>
            </div>
            <div className="flex gap-2 mt-3">
              <button
                onClick={handleFetchAndCache}
                className="flex-1 py-2 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition"
              >
                Ambil Data dari Server
              </button>
              <button
                onClick={() => {
                  setDateFilter({ start: '', end: '' })
                  setCacheStatus('idle')
                  setCachedOrders([])
                }}
                className="px-4 py-2 border border-amber-300 text-amber-700 text-sm rounded-lg"
              >
                Batal
              </button>
            </div>
          </div>
        )}

        {cacheStatus === 'loading' && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4 flex items-center gap-3">
            <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-blue-700 text-sm">
              Mengambil data dari server...
            </p>
          </div>
        )}

        {cacheStatus === 'loaded' && (
          <div className="flex items-center gap-2 text-xs text-gray-400 mb-3">
            <span>📦</span>
            <span>
              Data dari cache lokal ({cachedOrders.length} order)
            </span>
          </div>
        )}

        {/* Orders Table */}
        <Card padding="none" className="hidden lg:block">
          <Table>
            <TableHead>
              <TableRow>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('order_number')}
                >
                  <div className="flex items-center">Order # {getSortIcon('order_number')}</div>
                </TableHeader>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('customer_name')}
                >
                  <div className="flex items-center">Customer {getSortIcon('customer_name')}</div>
                </TableHeader>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center">Status {getSortIcon('status')}</div>
                </TableHeader>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('courier_id')}
                >
                  <div className="flex items-center">Courier {getSortIcon('courier_id')}</div>
                </TableHeader>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('payment_status')}
                >
                  <div className="flex items-center">Setoran {getSortIcon('payment_status')}</div>
                </TableHeader>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('total_fee')}
                >
                  <div className="flex items-center">Fee {getSortIcon('total_fee')}</div>
                </TableHeader>
                <TableHeader
                  className="cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('created_at')}
                >
                  <div className="flex items-center">Created {getSortIcon('created_at')}</div>
                </TableHeader>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredOrders.length === 0 ? (
                <TableEmpty colSpan={6} message="No orders found" />
              ) : (
                filteredOrders.map((order) => (
                  <TableRow
                    key={order.id}
                    className="cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => { setSelectedOrder(order); setIsDetailModalOpen(true); }}
                  >
                    <TableCell className="font-medium text-indigo-600">{order.order_number}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-medium text-gray-900">{order.customer_name}</span>
                        <span className="text-xs text-gray-500">{order.customer_phone}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(order.status)}>{getStatusLabel(order.status)}</Badge>
                    </TableCell>
                    <TableCell>{getCourierName(order.courier_id) || <span className="text-gray-400 italic">Unassigned</span>}</TableCell>
                    <TableCell>
                      {order.status === 'delivered' ? (
                        order.payment_status === 'paid' ? (
                          <Badge variant="success">Sudah Setor</Badge>
                        ) : (
                          isFinance && (
                            <Button
                              size="sm"
                              className="bg-orange-500 hover:bg-orange-600 text-white h-7 px-2 text-[10px]"
                              onClick={async (e) => {
                                e.stopPropagation()
                                const courierName = users.find(
                                  u => u.id === order.courier_id
                                )?.name || 'Kurir'
                                setBulkSettleCourierName(courierName)
                                
                                // Load unpaid dari IndexedDB
                                const unpaid =
                                  await getUnpaidOrdersByCourier(
                                    order.courier_id || ''
                                  )
                                setBulkUnpaidOrders(unpaid)
                                setShowBulkSettle(true)
                              }}
                            >
                              Konfirmasi Setor
                            </Button>
                          )
                        )
                      ) : (
                        <Badge variant="default" className="text-gray-400 border-gray-200">Belum Setor</Badge>
                      )}
                    </TableCell>
                    <TableCell>{formatCurrency(order.total_fee)}</TableCell>
                    <TableCell className="text-gray-500">{format(new Date(order.created_at), 'dd MMM HH:mm')}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>

        {/* Mobile List Info */}
        <div className="lg:hidden space-y-3">
          {filteredOrders.map(order => (
            <Card key={order.id} padding="sm" onClick={() => { setSelectedOrder(order); setIsDetailModalOpen(true); }}>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-bold text-indigo-600">{order.order_number}</p>
                  <p className="text-sm font-medium">{order.customer_name}</p>
                </div>
                <Badge variant={getStatusBadgeVariant(order.status)}>{getStatusLabel(order.status)}</Badge>
              </div>
              <div className="text-sm text-gray-500 flex justify-between">
                <span>{formatCurrency(order.total_fee)}</span>
                <span>{format(new Date(order.created_at), 'dd MMM')}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* CREATE ORDER MODAL */}
      <Modal isOpen={isCreateModalOpen} onClose={() => { setIsCreateModalOpen(false); setFormError(''); setIsCreating(false); }} title="New Order" size="lg">
        <div className="space-y-4">
          <div className="relative">
            <Input 
              label="Customer Name" 
              id="search_customer_name_field"
              name="search_customer_name_field"
              value={newOrder.customer_name} 
              onChange={e => handleCustomerNameChange(e.target.value)} 
              autoComplete="off"
            />
            {showSuggestions && customerSuggestions.length > 0 && (
              <div className="absolute z-50 w-full bg-white border border-gray-200 rounded-lg shadow-lg mt-1">
                {customerSuggestions.map((c, i) => (
                  <button key={i} type="button" onClick={() => handleSelectCustomer(c)}
                    className="w-full text-left px-4 py-3 hover:bg-gray-50 border-b last:border-0">
                    <p className="font-medium text-gray-900">{c.name}</p>
                    <p className="text-sm text-gray-500">{c.phone}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
          <Input 
            label="Phone Number" 
            id="search_customer_phone_field"
            name="search_customer_phone_field"
            value={newOrder.customer_phone} 
            onChange={e => setNewOrder({ ...newOrder, customer_phone: e.target.value })} 
            autoComplete="off"
          />
          
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-gray-700">Address</label>

            {/* List alamat tersimpan — satu baris per item */}
            {selectedCustomer && selectedCustomer.addresses.map((addr) => (
              <div
                key={addr.id}
                className={`flex items-center gap-2 px-2 py-1.5 rounded-lg border transition-colors ${
                  inlineEditAddrId === addr.id
                    ? 'border-indigo-400 bg-indigo-50'
                    : newOrder.customer_address === addr.address
                    ? 'border-indigo-300 bg-indigo-50/40'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {/* Radio pilih */}
                <button
                  type="button"
                  onClick={() => {
                    if (inlineEditAddrId !== addr.id) {
                      setNewOrder({ ...newOrder, customer_address: addr.address })
                    }
                  }}
                  className="flex-shrink-0"
                >
                  <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                    newOrder.customer_address === addr.address && inlineEditAddrId !== addr.id
                      ? 'border-indigo-500'
                      : 'border-gray-300'
                  }`}>
                    {newOrder.customer_address === addr.address && inlineEditAddrId !== addr.id && (
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    )}
                  </div>
                </button>

                {/* Label badge */}
                <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded flex-shrink-0 ${
                  addr.is_default ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-500'
                }`}>{addr.label}</span>

                {/* Inline edit mode */}
                {inlineEditAddrId === addr.id ? (
                  <>
                    <input
                      className="flex-1 text-sm border-0 bg-transparent outline-none focus:outline-none text-gray-800 min-w-0"
                      value={inlineEditValue}
                      autoFocus
                      onChange={e => setInlineEditValue(e.target.value)}
                      onKeyDown={async (e) => {
                        if (e.key === 'Enter') {
                          await updateAddress(selectedCustomer.id, addr.id, { address: inlineEditValue })
                          const updated = { ...selectedCustomer, addresses: selectedCustomer.addresses.map(a => a.id === addr.id ? { ...a, address: inlineEditValue } : a) }
                          setSelectedCustomer(updated)
                          if (newOrder.customer_address === addr.address) setNewOrder({ ...newOrder, customer_address: inlineEditValue })
                          setInlineEditAddrId(null)
                        } else if (e.key === 'Escape') {
                          setInlineEditAddrId(null)
                        }
                      }}
                    />
                    <button type="button" onClick={async () => {
                      await updateAddress(selectedCustomer.id, addr.id, { address: inlineEditValue })
                      const updated = { ...selectedCustomer, addresses: selectedCustomer.addresses.map(a => a.id === addr.id ? { ...a, address: inlineEditValue } : a) }
                      setSelectedCustomer(updated)
                      if (newOrder.customer_address === addr.address) setNewOrder({ ...newOrder, customer_address: inlineEditValue })
                      setInlineEditAddrId(null)
                    }} className="flex-shrink-0 text-green-600 hover:text-green-700">
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button type="button" onClick={() => setInlineEditAddrId(null)} className="flex-shrink-0 text-gray-400 hover:text-gray-600">
                      <XCircle className="w-3.5 h-3.5" />
                    </button>
                  </>
                ) : (
                  <>
                    <span className="flex-1 text-sm text-gray-700 truncate">{addr.address}</span>
                    {/* Tombol edit */}
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); setInlineEditAddrId(addr.id); setInlineEditValue(addr.address) }}
                      className="flex-shrink-0 text-gray-400 hover:text-indigo-600 transition-colors"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                    {/* Tombol hapus */}
                    <button
                      type="button"
                      onClick={async (e) => {
                        e.stopPropagation()
                        await deleteAddress(selectedCustomer.id, addr.id)
                        const updated = { ...selectedCustomer, addresses: selectedCustomer.addresses.filter(a => a.id !== addr.id) }
                        setSelectedCustomer(updated)
                        if (newOrder.customer_address === addr.address) {
                          const next = updated.addresses[0]
                          setNewOrder({ ...newOrder, customer_address: next ? next.address : '' })
                        }
                      }}
                      className="flex-shrink-0 text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </>
                )}
              </div>
            ))}

            {/* Inline tambah alamat baru */}
            {selectedCustomer && (
              inlineAddingNew ? (
                <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg border border-dashed border-indigo-400 bg-indigo-50">
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-600 flex-shrink-0">Baru</span>
                  <input
                    className="flex-1 text-sm border-0 bg-transparent outline-none focus:outline-none text-gray-800 min-w-0"
                    placeholder="Ketik alamat baru..."
                    value={inlineNewAddr}
                    autoFocus
                    onChange={e => setInlineNewAddr(e.target.value)}
                    onKeyDown={async (e) => {
                      if (e.key === 'Enter' && inlineNewAddr.trim()) {
                        const newAddrObj = { label: `Alamat ${selectedCustomer.addresses.length + 1}`, address: inlineNewAddr.trim(), is_default: selectedCustomer.addresses.length === 0, notes: '' }
                        await addAddress(selectedCustomer.id, newAddrObj)
                        const withNew = { ...selectedCustomer, addresses: [...selectedCustomer.addresses, { ...newAddrObj, id: 'temp' }] }
                        setSelectedCustomer(withNew)
                        setNewOrder({ ...newOrder, customer_address: inlineNewAddr.trim() })
                        setInlineNewAddr('')
                        setInlineAddingNew(false)
                      } else if (e.key === 'Escape') {
                        setInlineNewAddr(''); setInlineAddingNew(false)
                      }
                    }}
                  />
                  <button type="button" onClick={async () => {
                    if (!inlineNewAddr.trim()) return
                    const newAddrObj = { label: `Alamat ${selectedCustomer.addresses.length + 1}`, address: inlineNewAddr.trim(), is_default: selectedCustomer.addresses.length === 0, notes: '' }
                    await addAddress(selectedCustomer.id, newAddrObj)
                    const withNew = { ...selectedCustomer, addresses: [...selectedCustomer.addresses, { ...newAddrObj, id: 'temp' }] }
                    setSelectedCustomer(withNew)
                    setNewOrder({ ...newOrder, customer_address: inlineNewAddr.trim() })
                    setInlineNewAddr(''); setInlineAddingNew(false)
                  }} className="flex-shrink-0 text-green-600 hover:text-green-700">
                    <Check className="w-3.5 h-3.5" />
                  </button>
                  <button type="button" onClick={() => { setInlineNewAddr(''); setInlineAddingNew(false) }} className="flex-shrink-0 text-gray-400 hover:text-gray-600">
                    <XCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setInlineAddingNew(true)}
                  className="text-xs text-indigo-600 font-medium hover:text-indigo-700 flex items-center gap-1 mt-0.5"
                >
                  <Plus className="w-3 h-3" />
                  Tambah Alamat Baru
                </button>
              )
            )}

            {/* Input alamat untuk konsumen baru (tanpa selected customer) */}
            {!selectedCustomer && (
              <Textarea
                placeholder="Masukkan alamat lengkap..."
                value={newOrder.customer_address}
                onChange={e => setNewOrder({ ...newOrder, customer_address: e.target.value })}
              />
            )}
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">Daftar Barang (opsional)</p>
            {(newOrder.items || []).length > 0 && (
              <div className="space-y-1">
                {(newOrder.items || []).map((item, i) => (
                  <div key={i} className="flex items-center justify-between bg-gray-50 px-3 py-1.5 rounded-lg text-sm">
                    <span className="text-gray-800">{item.nama}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-gray-600">Rp {item.harga.toLocaleString('id-ID')}</span>
                      <button
                        type="button"
                        onClick={() => setNewOrder({ ...newOrder, items: (newOrder.items || []).filter((_, idx) => idx !== i) })}
                        className="text-gray-400 hover:text-red-500"
                      >✕</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Nama barang"
                id="new_item_nama"
                className="flex-1 border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-400"
              />
              <input
                type="text"
                inputMode="numeric"
                placeholder="Harga (Rp)"
                id="new_item_harga"
                className="w-32 border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-400"
              />
              <button
                type="button"
                onClick={() => {
                  const namaEl = document.getElementById('new_item_nama') as HTMLInputElement;
                  const hargaEl = document.getElementById('new_item_harga') as HTMLInputElement;
                  const nama = namaEl?.value.trim();
                  const harga = Number((hargaEl?.value || '').replace(/[^0-9]/g, ''));
                  if (!nama) return;
                  setNewOrder({ ...newOrder, items: [...(newOrder.items || []), { nama, harga }] });
                  if (namaEl) namaEl.value = '';
                  if (hargaEl) hargaEl.value = '';
                }}
                className="px-3 py-1.5 text-sm bg-indigo-600 text-white rounded-lg font-medium"
              >+ Tambah</button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Fee Ongkir"
              type="text"
              value={newOrder.total_fee !== undefined ? `Rp ${newOrder.total_fee.toLocaleString('id-ID')}` : ''}
              onChange={e => {
                const numericValue = Number(e.target.value.replace(/[^0-9]/g, ''));
                setNewOrder({ ...newOrder, total_fee: numericValue });
              }}
              placeholder="Rp 0"
            />
            <Input
              label="Estimated Delivery Time"
              type="datetime-local"
              value={newOrder.estimated_delivery_time}
              onChange={e => setNewOrder({ ...newOrder, estimated_delivery_time: e.target.value })}
            />

          </div>
          <Select
            label="Payment Status"
            value={newOrder.payment_status}
            onChange={e => setNewOrder({ ...newOrder, payment_status: e.target.value as any })}
            options={[
              { value: 'unpaid', label: 'Belum Setor' },
              { value: 'paid', label: 'Sudah Setor' }
            ]}
          />
          {formError && (
            <p className="text-sm text-red-500 mb-2">
              {formError}
            </p>
          )}
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => { setIsCreateModalOpen(false); setFormError(''); setIsCreating(false); }}>Cancel</Button>
            <Button onClick={handleCreateOrder} disabled={isCreating} isLoading={isCreating}>
              {isCreating ? 'Menyimpan...' : 'Create Order'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* DETAIL / ASSIGN MODAL */}
      <Modal isOpen={isDetailModalOpen} onClose={() => setIsDetailModalOpen(false)} title="Order Details" size="md">
        {selectedOrder && (
          <div className="space-y-3">
            {/* Header - compact */}
            <div className="flex justify-between items-center bg-gray-50 px-3 py-2 rounded-lg">
              <div>
                <span className="text-base font-bold text-gray-900">{selectedOrder.order_number}</span>
                <span className="text-xs text-gray-400 ml-2">{format(new Date(selectedOrder.created_at), 'dd MMM yy, HH:mm')}</span>
              </div>
              <Badge variant={getStatusBadgeVariant(selectedOrder.status)} size="sm">{getStatusLabel(selectedOrder.status)}</Badge>
            </div>

            {/* Customer + Payment — form if pending AND ops admin, otherwise read-only */}
            {selectedOrder.status === 'pending' && isOpsAdmin ? (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    label="Name"
                    value={editForm.customer_name}
                    onChange={e => setEditForm(prev => ({ ...prev, customer_name: e.target.value }))}
                  />
                  <Input
                    label="Phone"
                    value={editForm.customer_phone}
                    onChange={e => setEditForm(prev => ({ ...prev, customer_phone: e.target.value }))}
                  />
                </div>
                {/* Address — inline picker jika ada data customer, fallback Textarea */}
                <div className="space-y-1.5">
                  <label className="block text-sm font-medium text-gray-700">Address</label>

                  {editSelectedCustomer && editSelectedCustomer.addresses.map((addr) => (
                    <div
                      key={addr.id}
                      className={`flex items-center gap-2 px-2 py-1.5 rounded-lg border transition-colors ${
                        editInlineAddrId === addr.id
                          ? 'border-indigo-400 bg-indigo-50'
                          : editForm.customer_address === addr.address
                          ? 'border-indigo-300 bg-indigo-50/40'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <button type="button" onClick={() => {
                        if (editInlineAddrId !== addr.id)
                          setEditForm(prev => ({ ...prev, customer_address: addr.address }))
                      }} className="flex-shrink-0">
                        <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                          editForm.customer_address === addr.address && editInlineAddrId !== addr.id
                            ? 'border-indigo-500' : 'border-gray-300'
                        }`}>
                          {editForm.customer_address === addr.address && editInlineAddrId !== addr.id && (
                            <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                          )}
                        </div>
                      </button>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded flex-shrink-0 ${
                        addr.is_default ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-500'
                      }`}>{addr.label}</span>

                      {editInlineAddrId === addr.id ? (
                        <>
                          <input
                            className="flex-1 text-sm border-0 bg-transparent outline-none min-w-0 text-gray-800"
                            value={editInlineAddrValue}
                            autoFocus
                            onChange={e => setEditInlineAddrValue(e.target.value)}
                            onKeyDown={async (e) => {
                              if (e.key === 'Enter') {
                                await updateAddress(editSelectedCustomer.id, addr.id, { address: editInlineAddrValue })
                                const updated = { ...editSelectedCustomer, addresses: editSelectedCustomer.addresses.map(a => a.id === addr.id ? { ...a, address: editInlineAddrValue } : a) }
                                setEditSelectedCustomer(updated)
                                if (editForm.customer_address === addr.address) setEditForm(prev => ({ ...prev, customer_address: editInlineAddrValue }))
                                setEditInlineAddrId(null)
                              } else if (e.key === 'Escape') setEditInlineAddrId(null)
                            }}
                          />
                          <button type="button" onClick={async () => {
                            await updateAddress(editSelectedCustomer.id, addr.id, { address: editInlineAddrValue })
                            const updated = { ...editSelectedCustomer, addresses: editSelectedCustomer.addresses.map(a => a.id === addr.id ? { ...a, address: editInlineAddrValue } : a) }
                            setEditSelectedCustomer(updated)
                            if (editForm.customer_address === addr.address) setEditForm(prev => ({ ...prev, customer_address: editInlineAddrValue }))
                            setEditInlineAddrId(null)
                          }} className="flex-shrink-0 text-green-600 hover:text-green-700"><Check className="w-3.5 h-3.5" /></button>
                          <button type="button" onClick={() => setEditInlineAddrId(null)} className="flex-shrink-0 text-gray-400 hover:text-gray-600"><XCircle className="w-3.5 h-3.5" /></button>
                        </>
                      ) : (
                        <>
                          <span className="flex-1 text-sm text-gray-700 truncate">{addr.address}</span>
                          <button type="button" onClick={() => { setEditInlineAddrId(addr.id); setEditInlineAddrValue(addr.address) }} className="flex-shrink-0 text-gray-400 hover:text-indigo-600"><Pencil className="w-3 h-3" /></button>
                          <button type="button" onClick={async () => {
                            await deleteAddress(editSelectedCustomer.id, addr.id)
                            const updated = { ...editSelectedCustomer, addresses: editSelectedCustomer.addresses.filter(a => a.id !== addr.id) }
                            setEditSelectedCustomer(updated)
                            if (editForm.customer_address === addr.address) {
                              const next = updated.addresses[0]
                              setEditForm(prev => ({ ...prev, customer_address: next ? next.address : '' }))
                            }
                          }} className="flex-shrink-0 text-gray-400 hover:text-red-500"><Trash2 className="w-3 h-3" /></button>
                        </>
                      )}
                    </div>
                  ))}

                  {/* Tambah alamat baru inline */}
                  {editSelectedCustomer && (
                    editInlineAddingNew ? (
                      <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg border border-dashed border-indigo-400 bg-indigo-50">
                        <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-600 flex-shrink-0">Baru</span>
                        <input
                          className="flex-1 text-sm border-0 bg-transparent outline-none min-w-0 text-gray-800"
                          placeholder="Ketik alamat baru..."
                          autoFocus
                          value={editInlineAddrValue}
                          onChange={e => setEditInlineAddrValue(e.target.value)}
                          onKeyDown={async (e) => {
                            if (e.key === 'Enter' && editInlineAddrValue.trim()) {
                              const newA = { label: `Alamat ${editSelectedCustomer.addresses.length + 1}`, address: editInlineAddrValue.trim(), is_default: editSelectedCustomer.addresses.length === 0, notes: '' }
                              await addAddress(editSelectedCustomer.id, newA)
                              setEditSelectedCustomer({ ...editSelectedCustomer, addresses: [...editSelectedCustomer.addresses, { ...newA, id: 'temp' }] })
                              setEditForm(prev => ({ ...prev, customer_address: editInlineAddrValue.trim() }))
                              setEditInlineAddrValue('')
                              setEditInlineAddingNew(false)
                            } else if (e.key === 'Escape') { setEditInlineAddrValue(''); setEditInlineAddingNew(false) }
                          }}
                        />
                        <button type="button" onClick={async () => {
                          if (!editInlineAddrValue.trim()) return
                          const newA = { label: `Alamat ${editSelectedCustomer.addresses.length + 1}`, address: editInlineAddrValue.trim(), is_default: editSelectedCustomer.addresses.length === 0, notes: '' }
                          await addAddress(editSelectedCustomer.id, newA)
                          setEditSelectedCustomer({ ...editSelectedCustomer, addresses: [...editSelectedCustomer.addresses, { ...newA, id: 'temp' }] })
                          setEditForm(prev => ({ ...prev, customer_address: editInlineAddrValue.trim() }))
                          setEditInlineAddrValue('')
                          setEditInlineAddingNew(false)
                        }} className="flex-shrink-0 text-green-600 hover:text-green-700"><Check className="w-3.5 h-3.5" /></button>
                        <button type="button" onClick={() => { setEditInlineAddrValue(''); setEditInlineAddingNew(false) }} className="flex-shrink-0 text-gray-400 hover:text-gray-600"><XCircle className="w-3.5 h-3.5" /></button>
                      </div>
                    ) : (
                      <button type="button" onClick={() => { setEditInlineAddingNew(true); setEditInlineAddrValue('') }}
                        className="text-xs text-indigo-600 font-medium hover:text-indigo-700 flex items-center gap-1">
                        <Plus className="w-3 h-3" /> Tambah Alamat Baru
                      </button>
                    )
                  )}

                  {/* Fallback: konsumen belum di master → textarea bebas */}
                  {!editSelectedCustomer && (
                    <Textarea
                      value={editForm.customer_address}
                      onChange={e => setEditForm(prev => ({ ...prev, customer_address: e.target.value }))}
                      rows={2}
                    />
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    label="Fee"
                    value={editForm.total_fee ? `Rp ${editForm.total_fee.toLocaleString('id-ID')}` : ''}
                    onChange={e => {
                      const val = Number(e.target.value.replace(/[^0-9]/g, ''));
                      setEditForm(prev => ({ ...prev, total_fee: val }));
                    }}
                  />
                  <Select
                    label="Setoran"
                    value={editForm.payment_status}
                    onChange={e => setEditForm(prev => ({ ...prev, payment_status: e.target.value as any }))}
                    options={[
                      { value: 'unpaid', label: 'Belum Setor' },
                      { value: 'paid', label: 'Sudah Setor' }
                    ]}
                  />
                </div>

                {/* Daftar Belanja */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">
                    Daftar Belanja (opsional)
                  </label>

                  {/* List items yang sudah ada */}
                  {editItems.map((item, i) => (
                    <div key={i} className="flex items-center justify-between text-sm bg-gray-50 px-3 py-2 rounded-lg">
                      <span>{item.nama}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">
                          Rp {item.harga.toLocaleString('id-ID')}
                        </span>
                        <button
                          type="button"
                          onClick={() => setEditItems(
                            editItems.filter((_, idx) => idx !== i)
                          )}
                          className="text-red-400 hover:text-red-600 text-xs"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Input tambah item */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Nama barang"
                      value={editItemNama}
                      onChange={e => setEditItemNama(e.target.value)}
                      className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <input
                      type="number"
                      placeholder="Harga"
                      value={editItemHarga}
                      onChange={e => setEditItemHarga(e.target.value)}
                      className="w-28 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!editItemNama || !editItemHarga) return;
                        setEditItems([...editItems, {
                          nama: editItemNama,
                          harga: Number(editItemHarga)
                        }]);
                        setEditItemNama('');
                        setEditItemHarga('');
                      }}
                      className="px-3 py-2 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700"
                    >
                      +
                    </button>
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button size="sm" variant="secondary" onClick={handleSaveChanges}>Save Changes</Button>
                </div>
              </div>
            ) : (
              <div className="text-sm space-y-1.5">
                <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
                  <span className="text-gray-400">Customer</span>
                  <span className="font-medium text-gray-900">{selectedOrder.customer_name}</span>
                  <span className="text-gray-400">Phone</span>
                  <span>{selectedOrder.customer_phone}</span>
                  <span className="text-gray-400">Address</span>
                  <span className="whitespace-pre-wrap">{selectedOrder.customer_address}</span>
                  <span className="text-gray-400">Fee</span>
                  <span className="font-medium">{formatCurrency(selectedOrder.total_fee)}</span>
                  {((selectedOrder.items && selectedOrder.items.length > 0) || selectedOrder.item_name) && (
                    <>
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Daftar Barang</span>
                      {(selectedOrder.items && selectedOrder.items.length > 0) ? (
                        <div className="space-y-0.5">
                          {selectedOrder.items.map((item, i) => (
                            <div key={i} className="flex justify-between text-sm">
                              <span className="text-gray-800">{item.nama}</span>
                              <span className="text-gray-600 font-medium">Rp {item.harga.toLocaleString('id-ID')}</span>
                            </div>
                          ))}
                          <div className="flex justify-between text-sm font-semibold border-t border-gray-100 pt-1 mt-1">
                            <span className="text-gray-700">Total Belanja</span>
                            <span className="text-gray-800">Rp {selectedOrder.items.reduce((s, i) => s + i.harga, 0).toLocaleString('id-ID')}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-800">{selectedOrder.item_name || '-'}</span>
                          <span className="text-gray-600 font-medium">{selectedOrder.item_price ? `Rp ${selectedOrder.item_price.toLocaleString('id-ID')}` : '-'}</span>
                        </div>
                      )}
                    </>
                  )}
                  <span className="text-gray-400">Setoran</span>
                  <span>
                    <Badge variant={selectedOrder.payment_status === 'paid' ? 'success' : 'warning'} size="sm">
                      {selectedOrder.payment_status === 'paid' ? 'Sudah Setor' : 'Belum Setor'}
                    </Badge>
                  </span>
                  {selectedOrder.status === 'cancelled' && (
                    <>
                      <span className="text-gray-400">
                        Alasan Cancel
                      </span>
                      <span className="text-red-600 font-medium">
                        {selectedOrder.cancellation_reason || 'Tidak ada alasan'}
                      </span>
                      {selectedOrder.cancel_reason_type && (
                        <>
                          <span className="text-gray-400">
                            Dibatalkan oleh
                          </span>
                          <span className="capitalize">
                            {selectedOrder.cancel_reason_type === 'customer'
                              ? 'Permintaan Customer'
                              : selectedOrder.cancel_reason_type === 'item_unavailable'
                                ? 'Barang Tidak Tersedia'
                                : 'Lainnya'}
                          </span>
                        </>
                      )}
                    </>
                  )}
                </div>
              </div>
            )}

            <div className="border-t pt-2">
              {selectedOrder.status === 'pending' && isOpsAdmin ? (
                <div className="bg-indigo-50 px-3 py-2 rounded-lg border border-indigo-100">
                  <label className="block text-xs font-medium text-indigo-900 mb-1.5">Assign Courier (FIFO)</label>
                  <div className="flex gap-2">
                    <Select
                      className="flex-1"
                      placeholder="Select Courier..."
                      value={assignCourierId}
                      onChange={e => setAssignCourierId(e.target.value)}
                      options={availableCouriers.map(c => {
                        const waiting = courierWaitingOrder(c.id);
                        return {
                          value: c.id,
                          label: waiting
                            ? `${c.name} 📝 PENDING — ${waiting.order_number}` 
                            : `${c.name} (Online)` 
                        };
                      })}
                    />
                    <Button disabled={!assignCourierId} onClick={handleAssign}>Assign</Button>
                  </div>
                  {availableCouriers[0] && (
                    <p className="text-xs text-indigo-600 mt-1">
                      Recommended: <strong>{availableCouriers[0].name}</strong>
                      {courierWaitingOrder(availableCouriers[0].id) && (
                        <span className="ml-1 text-yellow-600">📝 sedang PENDING di penjual</span>
                      )}
                    </p>
                  )}
                  <div className="mt-2 space-y-1">
                    <label className="block text-xs font-medium text-indigo-900">Instruksi untuk Kurir</label>
                    <select
                      value={selectedOrder?.notes || ''}
                      onChange={e => setSelectedOrder(selectedOrder ? { ...selectedOrder, notes: e.target.value } : null)}
                      className="w-full border border-indigo-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-400 bg-white"
                    >
                      <option value="">— Tidak ada instruksi khusus —</option>
                      {courier_instructions.map((instruction) => (
                        <option key={instruction.id} value={instruction.label}>
                          {instruction.icon} {instruction.label}
                        </option>
                      ))}
                    </select>

                    {/* Preview ikon instruksi yang dipilih */}
                    {selectedOrder?.notes && (() => {
                      const match = courier_instructions.find(i => i.label === selectedOrder.notes)
                      if (!match) return null
                      return (
                        <div className="flex items-center gap-1.5 text-xs text-indigo-600 mt-1">
                          <span>{match.icon}</span>
                          <span>{match.instruction}</span>
                        </div>
                      )
                    })()}
                  </div>
                </div>
              ) : (
                <div className="text-sm grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
                  <span className="text-gray-400">Courier</span>
                  <span className="font-medium">{getCourierName(selectedOrder.courier_id)}</span>
                  {selectedOrder.assigned_at && (
                    <>
                      <span className="text-gray-400">Assigned</span>
                      <span>{format(new Date(selectedOrder.assigned_at), 'dd MMM yy, HH:mm')}</span>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Rincian Biaya Tambahan */}
            {selectedOrder.status !== 'pending' && ((selectedOrder.titik ?? 0) > 0 || (selectedOrder.beban ?? []).length > 0) && (
              <div className="border-t pt-2 text-sm space-y-1">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Rincian Biaya</p>
                <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
                  <span className="text-gray-400">Ongkir</span>
                  <span>{formatCurrency(selectedOrder.total_fee)}</span>
                  {(selectedOrder.titik ?? 0) > 0 && (
                    <>
                      <span className="text-gray-400">Titik ({selectedOrder.titik}x)</span>
                      <span>{formatCurrency(selectedOrder.total_biaya_titik ?? 0)}</span>
                    </>
                  )}
                  {(selectedOrder.beban ?? []).map((b, i) => (
                    <>
                      <span key={`beban-name-${i}`} className="text-gray-400 pl-2">• {b.nama}</span>
                      <span key={`beban-val-${i}`}>{formatCurrency(b.biaya)}</span>
                    </>
                  ))}
                  <span className="text-gray-700 font-semibold border-t pt-1 mt-0.5">Total Ongkir</span>
                  <span className="font-semibold text-gray-900 border-t pt-1 mt-0.5">
                    {formatCurrency(
                      (selectedOrder.total_fee || 0) +
                      (selectedOrder.total_biaya_titik ?? 0) +
                      (selectedOrder.total_biaya_beban ?? 0)
                    )}
                  </span>
                  {((selectedOrder.items && selectedOrder.items.length > 0) || (selectedOrder.item_price ?? 0) > 0) && (
                    <>
                      <span className="text-amber-800 font-bold border-t pt-1 mt-0.5">Total Dibayar Customer</span>
                      <span className="font-bold text-amber-800 border-t pt-1 mt-0.5">
                        {formatCurrency(
                          (selectedOrder.total_fee || 0) +
                          (selectedOrder.total_biaya_titik ?? 0) +
                          (selectedOrder.total_biaya_beban ?? 0) +
                          ((selectedOrder.items && selectedOrder.items.length > 0)
                            ? selectedOrder.items.reduce((s, i) => s + i.harga, 0)
                            : (selectedOrder.item_price ?? 0))
                        )}
                      </span>
                    </>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-between items-center pt-2 border-t">
              {isOpsAdmin && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={() => setIsCancelModalOpen(true)}
                  disabled={['delivered', 'cancelled'].includes(selectedOrder.status)}
                >
                  Cancel Order
                </Button>
              )}
              {!isOpsAdmin && <div />}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  leftIcon={<Printer className="h-3.5 w-3.5" />}
                  onClick={() => handlePrintInvoice(selectedOrder)}
                >
                  Print Invoice
                </Button>
                <Button variant="outline" size="sm" onClick={() => setIsDetailModalOpen(false)}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Cancel Confirmation */}
      <Modal isOpen={isCancelModalOpen} onClose={() => setIsCancelModalOpen(false)} title="Cancel Order">
        <div className="space-y-4">
          <p className="text-gray-600">Are you sure you want to cancel <strong>{selectedOrder?.order_number}</strong>?</p>
          <Textarea placeholder="Reason for cancellation..." value={cancelReason} onChange={e => setCancelReason(e.target.value)} />
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsCancelModalOpen(false)}>Back</Button>
            <Button variant="danger" disabled={!cancelReason} onClick={handleCancel}>Confirm Cancel</Button>
          </div>
        </div>
      </Modal>

      {/* Bulk Settlement Modal */}
      {showBulkSettle && (() => {
        // GANTI: unpaidOrders dari state bulkUnpaidOrders
        const unpaidOrders = bulkUnpaidOrders
        const totalPlatformFee = unpaidOrders
          .reduce((sum, o) =>
            sum + calcPlatformFee(o), 0)

        return (
          <div className="fixed inset-0
            bg-black/50 flex items-center
            justify-center z-50 px-4">
            <div className="bg-white rounded-xl
              p-6 w-full max-w-md">

              <h3 className="font-bold text-lg mb-1">
                💰 Konfirmasi Setoran
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Kurir: {bulkSettleCourierName}
              </p>

              {/* List order belum disetor */}
              <div className="space-y-2 mb-4
                max-h-64 overflow-y-auto">
                {unpaidOrders.length === 0 ? (
                  <p className="text-sm text-gray-500
                    text-center py-4">
                    Tidak ada order belum disetor
                  </p>
                ) : (
                  unpaidOrders.map(o => (
                    <div key={o.id}
                      className="flex justify-between
                      items-center text-sm bg-gray-50
                      px-3 py-2 rounded-lg">
                      <span className="font-medium">
                        {o.order_number}
                      </span>
                      <div className="text-right">
                        <p className="text-gray-500
                          text-xs">
                          Ongkir: {formatCurrency(
                            o.total_fee)}
                        </p>
                        <p className="font-semibold
                          text-orange-600">
                          Setor: {formatCurrency(
                            calcPlatformFee(o))}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Total */}
              {unpaidOrders.length > 0 && (
                <div className="border-t pt-3 mb-4">
                  <div className="flex justify-between
                    font-bold">
                    <span>Total Disetor</span>
                    <span className="text-orange-600">
                      {formatCurrency(totalPlatformFee)}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400
                    mt-1">
                    {unpaidOrders.length} order ·
                    menggunakan rate saat pengiriman
                  </p>
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={() => setShowBulkSettle(false)}
                  className="flex-1 py-2.5 border
                    border-gray-200 rounded-xl
                    text-sm text-gray-600"
                >
                  Batal
                </button>
                <button
                  disabled={unpaidOrders.length === 0}
                  onClick={async () => {
                    await Promise.all(
                      unpaidOrders.map(async o => {
                        await updateOrder(o.id,
                          { payment_status: 'paid' })
                        await markAsPaidInLocalDB(o.id)
                      })
                    )
                    // Refresh local orders
                    const weekOrders = await getOrdersForWeek()
                    setLocalDBOrders(weekOrders)
                    setShowBulkSettle(false)
                  }}
                  className="flex-1 py-2.5
                    bg-orange-500 hover:bg-orange-600
                    text-white rounded-xl text-sm
                    font-semibold disabled:opacity-50
                    transition"
                >
                  Konfirmasi Setor Semua
                </button>
              </div>

            </div>
          </div>
        )
      })()}
    </div>
  );
}
